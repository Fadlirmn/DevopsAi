# knowledgeops-ai — VPS-first PRD package

**Version:** 2.0 · Date: 2026-11-23

Scope: RAG, pgvector, Python worker, SvelteKit, TLS.

- `PRD.md` — full product requirements, feature/API/data design and VPS-first architecture.
- `IMPLEMENTATION.md` — staged build and deployment implementation checklist.
- `infra/DEPLOY_VPS.md` — VPS deployment topology, operations and constraints.
- `infra/.env.example` — sample environment keys (no credentials).
- `infra/Caddyfile` — HTTPS reverse proxy template, adapt API health/routes.

**Important:** these are implementation specifications/templates, **not complete working application source**. Application source code, Dockerfiles, database migrations and service configurations described in the PRD must be implemented before a production deployment.

Default production target: a VPS with Docker Compose. Vercel is optional read-only demo deployment, not a runtime requirement.
